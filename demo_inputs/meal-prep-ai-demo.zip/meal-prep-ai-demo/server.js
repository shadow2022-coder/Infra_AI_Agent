require('dotenv').config();
const express = require('express');
const cors = require('cors');
const path = require('path');
const fs = require('fs');

const app = express();
const PORT = Number(process.env.PORT || 3000);
const recipes = JSON.parse(fs.readFileSync(path.join(__dirname, 'data', 'recipes.json'), 'utf8'));

// INTENTIONAL SAFE DEMO ISSUE #2: wildcard CORS for scanner testing.
app.use(cors({ origin: '*' }));

// INTENTIONAL SAFE DEMO ISSUE #3: missing security headers.
// Helmet is intentionally not used so defensive scanners can detect missing headers.

app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

function filterRecipes({ diet, maxTime, maxCalories, query }) {
  return recipes.filter((recipe) => {
    const dietOk = !diet || diet === 'all' || recipe.diet === diet;
    const timeOk = !maxTime || recipe.timeMinutes <= Number(maxTime);
    const caloriesOk = !maxCalories || recipe.calories <= Number(maxCalories);
    const searchText = `${recipe.name} ${recipe.diet} ${recipe.tags.join(' ')} ${recipe.ingredients.join(' ')}`.toLowerCase();
    const queryOk = !query || searchText.includes(String(query).toLowerCase());
    return dietOk && timeOk && caloriesOk && queryOk;
  });
}

app.get('/health', (_req, res) => {
  res.json({ ok: true, service: 'meal-prep-ai-demo', port: PORT });
});

app.get('/api/health', (_req, res) => {
  res.json({ ok: true, service: 'meal-prep-ai-demo', port: PORT, timestamp: new Date().toISOString() });
});

app.get('/api/recipes', (req, res) => {
  const result = filterRecipes(req.query);
  res.json({ count: result.length, recipes: result });
});

app.post('/api/meal-plan', (req, res) => {
  const { diet = 'all', days = 3, maxTime = 30 } = req.body || {};
  const candidates = filterRecipes({ diet, maxTime });
  const source = candidates.length ? candidates : recipes;
  const plan = Array.from({ length: Math.min(Number(days) || 3, 5) }, (_, index) => {
    const recipe = source[index % source.length];
    return {
      day: index + 1,
      recipe,
      prepTip: `Batch prep ${recipe.ingredients.slice(0, 3).join(', ')} and store sauces separately.`
    };
  });
  res.json({ plan, generatedBy: 'local-mock-ai', externalCalls: false });
});

app.post('/api/ai/suggest', (req, res) => {
  const { goal = 'balanced', pantry = '' } = req.body || {};
  const pantryItems = String(pantry)
    .split(',')
    .map((item) => item.trim())
    .filter(Boolean);

  const matched = recipes.find((recipe) =>
    pantryItems.some((item) => recipe.ingredients.join(' ').toLowerCase().includes(item.toLowerCase()))
  ) || recipes[0];

  res.json({
    mode: 'fake-local-ai',
    externalCalls: false,
    goal,
    suggestion: `For a ${goal} goal, start with ${matched.name}. Prep grains first, protein second, and keep wet toppings separate.`,
    matchedRecipe: matched
  });
});

// INTENTIONAL SAFE DEMO ISSUE #5: unprotected admin route.
app.get('/admin', (_req, res) => {
  res.send(`<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Unprotected Admin - Demo</title>
  <link rel="stylesheet" href="/styles.css" />
</head>
<body>
  <main class="admin-shell">
    <a href="/" class="back-link">← Back to app</a>
    <section class="card danger-card">
      <p class="eyebrow">Intentional demo issue</p>
      <h1>Unprotected Admin Panel</h1>
      <p>This page is intentionally public for defensive scanner testing. It contains only fake demo data.</p>
      <div class="admin-grid">
        <div><strong>Demo users</strong><span>128</span></div>
        <div><strong>Fake API status</strong><span>mock-only</span></div>
        <div><strong>Billing</strong><span>disabled</span></div>
      </div>
    </section>
  </main>
</body>
</html>`);
});

// INTENTIONAL SAFE DEMO ISSUE #5: unprotected debug route with fake config only.
app.get('/debug', (_req, res) => {
  res.json({
    warning: 'Intentional demo issue: unprotected debug endpoint with fake values only.',
    env: 'local-demo',
    fakeMealAiKeyPreview: `${String(process.env.FAKE_MEAL_AI_API_KEY || '').slice(0, 14)}...`,
    publicMealPrepKey: process.env.PUBLIC_MEAL_PREP_KEY,
    cors: 'wildcard',
    securityHeaders: 'intentionally missing',
    externalCalls: false
  });
});

app.use((_req, res) => {
  res.status(404).json({ error: 'Not found', hint: 'Try /, /api/health, /api/recipes, /admin, or /debug' });
});

app.listen(PORT, () => {
  console.log('==============================================');
  console.log(`MealPrep AI Demo running on http://localhost:${PORT}`);
  console.log(`Health route: http://localhost:${PORT}/api/health`);
  console.log(`Port: ${PORT}`);
  console.log('External API calls: disabled; local mock data only.');
  console.log('==============================================');
});
