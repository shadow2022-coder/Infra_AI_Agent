# Security Demo Notes

This app intentionally includes safe, non-destructive issues to verify defensive scanners:

- Committed fake `.env` secrets.
- Wildcard CORS.
- Missing common security headers.
- Public fake frontend env value.
- Unprotected `/admin` and `/debug` routes.

All values are fake. The app is designed for local scanner validation and demo reports.
