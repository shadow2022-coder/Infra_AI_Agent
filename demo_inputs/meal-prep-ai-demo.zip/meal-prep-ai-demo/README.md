# MealPrep AI Demo

A small usable meal-prep web application for **defensive security scanner testing**. It runs locally on one port, has a polished UI, mock AI meal suggestions, mock recipe data, and safe intentional demo security issues.

> This app does **not** call real third-party APIs. All recipe and AI behavior is local/mock only.

## Exact local run command

```bash
npm install && npm start
```

Open:

```text
http://localhost:3000
```

Health checks:

```text
http://localhost:3000/health
http://localhost:3000/api/health
```

## Docker run

```bash
docker build -t meal-prep-ai-demo . && docker run --rm -p 3000:3000 meal-prep-ai-demo
```

## What the app does

- Search local meal-prep recipes by diet, time, and calories.
- Generate a 3-day meal prep plan from local mock data.
- Use a fake local “AI helper” endpoint to suggest prep tips.
- Show simple local SVG food images.
- Expose health and debug/admin routes for scanner testing.

## Safe intentional security issues

These are intentionally included for defensive scanner testing only:

1. `.env` file is committed with **fake API keys only**.
2. Wildcard CORS is enabled with `origin: "*"`.
3. Security headers are intentionally missing. The app does not use Helmet.
4. Fake frontend key is visible in `public/app.js` and in the UI.
5. `/admin` and `/debug` are intentionally unprotected.

## Safety boundaries

This project contains no malware, destructive code, crypto miners, reverse shells, scanners, brute force logic, exploit code, or external attack behavior.
