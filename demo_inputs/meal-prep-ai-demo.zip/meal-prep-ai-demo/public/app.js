// INTENTIONAL SAFE DEMO ISSUE #4: visible fake frontend env value.
// This is fake and included only for defensive scanner testing.
window.MEALPREP_PUBLIC_FAKE_KEY = 'pk_demo_fake_frontend_mealprep_visible_98765';

const recipesEl = document.querySelector('#recipes');
const recipeCountEl = document.querySelector('#recipeCount');
const planEl = document.querySelector('#plan');
const publicKeyEl = document.querySelector('#publicKey');
const featuredMealEl = document.querySelector('#featuredMeal');

publicKeyEl.textContent = window.MEALPREP_PUBLIC_FAKE_KEY;

async function fetchRecipes(params = {}) {
  const query = new URLSearchParams(params).toString();
  const response = await fetch(`/api/recipes?${query}`);
  if (!response.ok) throw new Error('Could not load recipes');
  return response.json();
}

function renderRecipes(recipes) {
  recipeCountEl.textContent = `${recipes.length} recipes`;
  recipesEl.innerHTML = recipes.map((recipe) => `
    <article class="recipe-card">
      <img src="${recipe.image}" alt="${recipe.name}" />
      <div class="recipe-body">
        <p class="eyebrow">${recipe.diet}</p>
        <h3>${recipe.name}</h3>
        <p>${recipe.ingredients.slice(0, 4).join(' · ')}</p>
        <div class="recipe-meta">
          <span>${recipe.timeMinutes} min</span>
          <span>${recipe.calories} kcal</span>
          <span>${recipe.protein}g protein</span>
        </div>
        <div class="tags">
          ${recipe.tags.slice(0, 3).map((tag) => `<span>#${tag}</span>`).join('')}
        </div>
      </div>
    </article>
  `).join('');

  if (recipes[0]) featuredMealEl.textContent = recipes[0].name;
}

function renderPlan(plan) {
  planEl.innerHTML = plan.map((item) => `
    <article class="plan-card">
      <span class="day-pill">Day ${item.day}</span>
      <h3>${item.recipe.name}</h3>
      <p>${item.prepTip}</p>
      <div class="recipe-meta">
        <span>${item.recipe.timeMinutes} min</span>
        <span>${item.recipe.calories} kcal</span>
      </div>
    </article>
  `).join('');
}

async function loadInitial() {
  try {
    const data = await fetchRecipes();
    renderRecipes(data.recipes);
  } catch (error) {
    recipesEl.innerHTML = `<p class="result-text">${error.message}</p>`;
  }
}

document.querySelector('#recipeForm').addEventListener('submit', async (event) => {
  event.preventDefault();
  const diet = document.querySelector('#diet').value;
  const maxTime = document.querySelector('#maxTime').value;
  const query = document.querySelector('#query').value;
  const data = await fetchRecipes({ diet, maxTime, query });
  renderRecipes(data.recipes);
});

document.querySelector('#generatePlanBtn').addEventListener('click', async () => {
  const diet = document.querySelector('#diet').value;
  const maxTime = document.querySelector('#maxTime').value;
  const response = await fetch('/api/meal-plan', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ diet, maxTime, days: 3 })
  });
  const data = await response.json();
  renderPlan(data.plan);
});

document.querySelector('#aiSuggestBtn').addEventListener('click', async () => {
  const pantry = document.querySelector('#pantry').value;
  const goal = document.querySelector('#goal').value;
  const response = await fetch('/api/ai/suggest', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ pantry, goal })
  });
  const data = await response.json();
  document.querySelector('#aiResult').textContent = data.suggestion;
});

document.querySelector('#healthBtn').addEventListener('click', async () => {
  const response = await fetch('/api/health');
  const data = await response.json();
  alert(`Health OK: ${data.ok}\nPort: ${data.port}\nService: ${data.service}`);
});

loadInitial();
